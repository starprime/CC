#!/bin/bash
aws configure set aws_access_key_id AKIAJMNZAIPO2LP6EVPA
aws configure set aws_secret_access_key 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
aws configure set default.region us-west-2
aws configure set default.output text

aws ec2 describe-instances --query 'Reservations[*].Instances[*].[InstanceId]' --output text >listofinstance.txt
current_date_time="`date +%Y-%m-%dT%H:%M:%S`";
echo $current_date_time;
OLDERDATE="`date "+%Y-%m-%dT%H:%M:%S" -d "1 day ago"`";
echo $OLDERDATE

input="listofinstance.txt"
while IFS= read -r instance
do
  echo $instance
  aws cloudwatch get-metric-statistics --metric-name CPUUtilization --namespace AWS/EC2 --dimensions Name=InstanceId,Value=$instance --statistics Average --start-time $OLDERDATE --end-time $current_date_time --period 86400

  echo
done < "$input"
rm listofinstance.txt