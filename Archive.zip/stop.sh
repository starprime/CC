#!/bin/bash
aws configure set aws_access_key_id AKIAJMNZAIPO2LP6EVPA
aws configure set aws_secret_access_key 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
aws configure set default.region us-west-2
aws configure set default.output text


aws ec2 stop-instances --instance-ids  i-0c76620d8611a3109
